<h1>hello supervisor</h1>
<?php /**PATH E:\aldi\project\input excel laravel\TestingAuth\resources\views/role_layouts/supervisor.blade.php ENDPATH**/ ?>