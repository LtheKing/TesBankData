<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">

        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Hello Karyawan</div>
                <div class="card-body">
                    <form action="<?php echo e(route('storeFile')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="form-group row">
                            <input type="file" name="featured_file" id="" class="form-control"><br>
                            <button type="submit" class="btn btn-dark form-control">Upload Now</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\aldi\project\input excel laravel\TestingAuth\resources\views/role_layouts/karyawan.blade.php ENDPATH**/ ?>