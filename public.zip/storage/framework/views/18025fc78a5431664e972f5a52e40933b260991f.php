<?php $__env->startSection('content'); ?>
    <h1>hello direktur</h1>
    <input type="file" name="featured_image" id="" class="form-control"><br>
        <button type="submit" class="btn btn-dark form-control">Upload Now</button>

    <a href="<?php echo e(route('nasabah')); ?>" class="btn btn-info">Data Nasabah</a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\aldi\project\input excel laravel\TestingAuth\resources\views/role_layouts/direktur.blade.php ENDPATH**/ ?>