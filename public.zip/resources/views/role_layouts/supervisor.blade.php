@extends('layouts.app')

@section('content')
    <h1>hello Supervisor</h1>
@endsection
